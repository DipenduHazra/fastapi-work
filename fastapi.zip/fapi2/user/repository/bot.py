from sqlalchemy.orm import Session
from .. import models,schemas
from fastapi import HTTPException,status

def create(request:schemas.Bot,db:Session):
    new_bot=models.Bot(name=request.name,description=request.description,default_settings=request.default_settings,schema_model=request.schema_model)
    db.add(new_bot)#add the new blog to the database
    db.commit() #commit the changes in the database
    db.refresh(new_bot) #refresh db to return the newly created blog
    return new_bot

def get_all(db:Session):
    bots=db.query(models.Bot).all()
    #In order to get all the user from the database, just query the database using the db instance
    # Use all() function to get all the users from the database 
    return bots

def show(id:int,db:Session):
    bot=db.query(models.Bot).filter(models.Bot.id==id).first()
    if not bot:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f"Bot with id {id} is not available")
    
    return bot


def update(id:int,db:Session,request:schemas.Bot):
    #this method is a bulk operation
    #query the bot
    bot=db.query(models.Bot).filter(models.Bot.id==id)
    #check if the user is available or not
    #if user is not available,raise an exception
    if not bot.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f"Bot with id {id} is not available")
    
    #if user is available,delete the user
    bot.update({'name':request.name,'description':request.description,'default_settings':request.default_settings,'schema_model':request.schema_model})
    #update the entire request structure
    db.commit() #commit the changes
    return bot.first()
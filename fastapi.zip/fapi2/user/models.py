from sqlalchemy import Column,Integer,String
from .database import Base

class User(Base):
    __tablename__='users'
    id=Column(Integer,primary_key=True,index=True)
    Email=Column(String)
    Password=Column(String)
    Designation=Column(String)
    Organization=Column(String)
    Role=Column(String)

class Bot(Base):
    __tablename__='bots'
    id=Column(Integer,primary_key=True,index=True)
    name=Column(String)
    description=Column(String)
    default_settings=Column(String)
    schema_model=Column(String)

class Session(Base):
    __tablename__='Session'
    id=Column(Integer,primary_key=True,index=True)
    title=Column(String)
    bot=Column(String)
    

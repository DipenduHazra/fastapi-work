from sqlalchemy.orm import Session
from .. import models,schemas
from fastapi import HTTPException,status
from ..hashing import Hash
from fastapi_pagination import Page,paginate

def get_all(db:Session):
    users=db.query(models.User).all()
    #In order to get all the user from the database, just query the database using the db instance
    # Use all() function to get all the users from the database 
    return users

def create(request:schemas.User,db:Session):
    new_user=models.User(Email=request.Email,Password=Hash.bcrypt(request.Password),Designation=request.Designation,Organization=request.Organization,Role=request.Role)
    db.add(new_user)#add the new blog to the database
    db.commit() #commit the changes in the database
    db.refresh(new_user) #refresh db to return the newly created blog
    return new_user

def show(id:int,db:Session):
    user=db.query(models.User).filter(models.User.id==id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f"User with id {id} is not available")
    
    return user


def update(id:int,db:Session,request:schemas.User):
    #this method is a bulk operation
    #query the user
    user=db.query(models.User).filter(models.User.id==id)
    #check if the user is available or not
    #if user is not available,raise an exception
    if not user.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f"User with id {id} is not available")
    
    #if user is available,delete the user
    user.update({'Email':request.Email,'Password':Hash.bcrypt(request.Password),'Designation':request.Designation,'Organization':request.Organization,'Role':request.Role})
    #update the entire request structure
    db.commit() #commit the changes
    return user.first()




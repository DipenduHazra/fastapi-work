from sqlalchemy import create_engine

from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.orm import sessionmaker
#import all these packages is compulsory and the basic step for database connection

SQLALCHEMY_DATABASE_URL = 'sqlite:///./user.db' #defining database URL
#create engine
engine=create_engine(SQLALCHEMY_DATABASE_URL,connect_args={'check_same_thread':False})
#create sessionlocal using the engine created
SessionLocal=sessionmaker(bind=engine,autocommit=False, autoflush=False)
#create the base
Base=declarative_base()

def get_db():
    db=SessionLocal() #SessionLocal is from the database, so, we have to import that from database
    try:
        yield db
    finally:
        db.close()


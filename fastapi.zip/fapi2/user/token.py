from datetime import datetime,timedelta
from jose import JWTError,jwt
from . import schemas

SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256" #this algorithm is used to encode the secret key
ACCESS_TOKEN_EXPIRE_MINUTES = 30

#generate JWT access token
#The function needs the data, which we are going to pass
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    #expire=expiration time
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(token:str,credentials_exception):
    #decode the JWT access token
    try:
        payload=jwt.decode(token,SECRET_KEY,algorithms=[ALGORITHM])
        email:str=payload.get("sub")
        #if there is no email, raise the exception
        if email is None:
            raise credentials_exception
        
        token_data=schemas.TokenData(email=email)
    except JWTError:
        raise credentials_exception
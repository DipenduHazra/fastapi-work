from pydantic import BaseModel,EmailStr
from typing import Optional

class User(BaseModel):
    Email:EmailStr
    Password:str
    Designation:str
    Organization:str
    Role:str

class ShowUser(BaseModel):
    Email:str
    Designation:str
    Organization:str
    Role:str

    class Config():
        orm_mode=True

class Login(BaseModel):
    username:str
    password:str
    

class TokenData(BaseModel):
    email:Optional[str]=None

class Bot(BaseModel):
    name:str
    description:str
    default_settings:str
    schema_model:str

class showbot(BaseModel):
    name:str
    description:str
    default_settings:str
    schema_model:str

    class Config():
        orm_mode=True

class session(BaseModel):
    title:str
    bot:str

class showsession(BaseModel):
    title:str
    bot:str
    class Config():
        orm_mode=True



from sqlalchemy.orm import Session
from .. import models,schemas
from fastapi import HTTPException,status

def create(request:schemas.session,db:Session):
    new_session=models.Session(title=request.title,bot=request.bot)
    db.add(new_session)#add the new blog to the database
    db.commit() #commit the changes in the database
    db.refresh(new_session) #refresh db to return the newly created blog
    return new_session

def get_all(db:Session):
    sessions=db.query(models.Session).all()
    #In order to get all the user from the database, just query the database using the db instance
    # Use all() function to get all the users from the database 
    return sessions

def show(id:int,db:Session):
    session=db.query(models.Session).filter(models.Session.id==id).first()
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f"Session schema with id {id} is not available")
    
    return session


def update(id:int,db:Session,request:schemas.session):
    #this method is a bulk operation
    #query the bot
    session=db.query(models.Session).filter(models.Session.id==id)
    #check if the user is available or not
    #if user is not available,raise an exception
    if not session.first():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail=f"Session schema with id {id} is not available")
    
    #if user is available,delete the user
    session.update({'title':request.title,'bot':request.bot})
    #update the entire request structure
    db.commit() #commit the changes
    return session.first()